package com.tapsmith.app

import android.content.Context
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** Everything the engine can do. Profiles are just JSON lists of these. */
@Serializable
sealed interface Step

@Serializable @SerialName("tap")
data class Tap(val x: Int, val y: Int) : Step

@Serializable @SerialName("swipe")
data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val ms: Long = 300) : Step

@Serializable @SerialName("wait")
data class Wait(val ms: Long, val jitterMs: Long = 0) : Step

/** Search the screen for a saved image target. timeoutMs 0 = look once. */
@Serializable @SerialName("find")
data class Find(
    val target: String,
    val tapIt: Boolean = true,
    val timeoutMs: Long = 0,
    val threshold: Double = 0.85,
    val onFound: List<Step> = emptyList(),
    val onMissing: List<Step> = emptyList(),
) : Step

/** times = 0 means forever. maxMinutes = 0 means no time cap. */
@Serializable @SerialName("loop")
data class Loop(val times: Int = 0, val maxMinutes: Int = 0, val steps: List<Step>) : Step

@Serializable @SerialName("stop")
data object Stop : Step

@Serializable
data class Profile(val name: String, val steps: List<Step>)

object ProfileStore {
    private val json = Json {
        classDiscriminator = "type"
        prettyPrint = true
        encodeDefaults = true
        ignoreUnknownKeys = true
    }

    private fun file(ctx: Context) = File(ctx.filesDir, "profile.json")

    fun parse(text: String): Profile = json.decodeFromString<Profile>(text)

    fun loadText(ctx: Context): String {
        val f = file(ctx)
        if (!f.exists()) f.writeText(json.encodeToString(demo(ctx)))
        return f.readText()
    }

    fun load(ctx: Context): Profile = parse(loadText(ctx))

    /** Throws if the JSON is invalid, so bad edits never get saved. */
    fun save(ctx: Context, text: String) {
        parse(text)
        file(ctx).writeText(text)
    }

    private fun demo(ctx: Context): Profile {
        val m = ctx.resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        return Profile(
            name = "Demo: swipe up, tap middle",
            steps = listOf(
                Loop(
                    times = 5,
                    steps = listOf(
                        Swipe(w / 2, h * 3 / 4, w / 2, h / 4, 400),
                        Wait(800, 300),
                        Tap(w / 2, h / 2),
                        Wait(1000, 400),
                    ),
                ),
            ),
        )
    }
}
