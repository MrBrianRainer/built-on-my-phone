package com.tapsmith.app

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.random.Random

data class Hit(val x: Int, val y: Int)

/** Vision plugs in here. v0.1 ships a stub; v0.2 swaps in screen capture + OpenCV. */
interface Matcher {
    suspend fun find(target: String, threshold: Double): Hit?
}

object NoMatcher : Matcher {
    override suspend fun find(target: String, threshold: Double): Hit? = null
}

private class StopSignal : RuntimeException()

class Runner(
    private val matcher: Matcher,
    private val onCount: (Int) -> Unit,
) {
    private var count = 0

    suspend fun run(profile: Profile) {
        val svc = TapService.instance ?: error("Tap service is off")
        count = 0
        try {
            exec(svc, profile.steps)
        } catch (_: StopSignal) {
            // a Stop step ended the run on purpose
        }
    }

    private fun bump() { count++; onCount(count) }
    private fun jit(v: Int) = v + Random.nextInt(-4, 5)
    private fun now() = System.currentTimeMillis()

    private suspend fun exec(svc: TapService, steps: List<Step>) {
        for (s in steps) {
            currentCoroutineContext().ensureActive()
            when (s) {
                is Tap -> { svc.tap(jit(s.x), jit(s.y)); bump() }
                is Swipe -> { svc.swipe(jit(s.x1), jit(s.y1), jit(s.x2), jit(s.y2), s.ms); bump() }
                is Wait -> {
                    val j = if (s.jitterMs > 0) Random.nextLong(-s.jitterMs, s.jitterMs + 1) else 0L
                    delay((s.ms + j).coerceAtLeast(0L))
                }
                is Find -> {
                    val start = now()
                    var hit: Hit? = null
                    while (true) {
                        hit = matcher.find(s.target, s.threshold)
                        if (hit != null || now() - start >= s.timeoutMs) break
                        delay(300)
                    }
                    if (hit != null) {
                        if (s.tapIt) { svc.tap(jit(hit.x), jit(hit.y)); bump() }
                        exec(svc, s.onFound)
                    } else {
                        exec(svc, s.onMissing)
                    }
                }
                is Loop -> {
                    val end = if (s.maxMinutes > 0) now() + s.maxMinutes * 60_000L else Long.MAX_VALUE
                    var i = 0
                    while ((s.times == 0 || i < s.times) && now() < end) {
                        exec(svc, s.steps)
                        i++
                        delay(50) // never spin the CPU on an empty loop
                    }
                }
                is Stop -> throw StopSignal()
            }
        }
    }
}
