package com.tapsmith.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Floating bubble. Tap = run/stop. Drag = move. Long-press = close. */
class OverlayService : Service() {

    private enum class Mode(val color: Int, val label: String) {
        IDLE(0xFFFF5C8A.toInt(), "▶"),
        RUN(0xFF2EC4B6.toInt(), "0"),
        DONE(0xFF8E7DFF.toInt(), "✓"),
        ERROR(0xFFE63946.toInt(), "!"),
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        goForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    override fun onDestroy() {
        scope.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bubble", "Tapsmith bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "bubble")
            .setContentTitle("Tapsmith bubble is on")
            .setContentText("Long-press the bubble to close it")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun ui(block: () -> Unit) { main.post { block() } }
    private fun toast(msg: String) = ui { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun paint(m: Mode, text: String = m.label) {
        val v = bubble ?: return
        v.text = text
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(m.color)
            setStroke((3 * resources.displayMetrics.density).toInt(), Color.WHITE)
        }
    }

    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (60 * d).toInt()
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        bubble = tv
        paint(Mode.IDLE)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (200 * d).toInt()
        }
        tv.setOnTouchListener(DragListener(lp))
        wm.addView(tv, lp)
    }

    private fun toggle() {
        if (job?.isActive == true) {
            job?.cancel()
            paint(Mode.IDLE)
            return
        }
        if (TapService.instance == null) {
            paint(Mode.ERROR)
            toast("Tap service is off. Enable it in Accessibility settings.")
            return
        }
        val profile = try {
            ProfileStore.load(this)
        } catch (e: Exception) {
            paint(Mode.ERROR)
            toast("Profile error: ${e.message?.take(100)}")
            return
        }
        paint(Mode.RUN)
        job = scope.launch {
            try {
                Runner(NoMatcher) { n -> ui { paint(Mode.RUN, n.toString()) } }.run(profile)
                ui { paint(Mode.DONE) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui {
                    paint(Mode.ERROR)
                    toast(e.message ?: "Run failed")
                }
            }
        }
    }

    private inner class DragListener(val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (e.eventTime - e.downTime > 600) stopSelf() else toggle()
                }
            }
            return true
        }
    }
}
