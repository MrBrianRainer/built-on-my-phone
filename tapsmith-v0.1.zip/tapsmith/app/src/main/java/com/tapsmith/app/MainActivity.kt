package com.tapsmith.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Indigo = Color(0xFF1B1464)
private val Coral = Color(0xFFFF5C8A)
private val Teal = Color(0xFF2EC4B6)
private val Butter = Color(0xFFFFD23F)
private val Panel = Color(0xFF2A2180)

class MainActivity : ComponentActivity() {
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { TapsmithTheme { Home(refresh) } }
    }

    override fun onResume() {
        super.onResume()
        refresh++ // re-check permissions when coming back from Settings
    }
}

@Composable
fun TapsmithTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Coral,
            onPrimary = Color.White,
            secondary = Teal,
            background = Indigo,
            surface = Panel,
        ),
        content = content,
    )
}

@Composable
private fun StatusRow(label: String, ready: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(if (ready) Teal else Butter))
        Spacer(Modifier.width(10.dp))
        Text(
            "$label: ${if (ready) "ready" else "needs setup"}",
            color = Color.White,
            fontSize = 15.sp,
        )
    }
}

@Composable
fun Home(refresh: Int) {
    val ctx = LocalContext.current
    val tapOn = refresh >= 0 && TapService.instance != null
    val overlayOn = refresh >= 0 && Settings.canDrawOverlays(ctx)
    var text by remember { mutableStateOf(ProfileStore.loadText(ctx)) }
    var msg by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(Indigo)
            .systemBarsPadding()
            .imePadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Tapsmith", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Butter)
        Text("Build a recipe of taps, swipes, searches and loops.", color = Color(0xFFCFCBFF), fontSize = 14.sp)

        StatusRow("Tap service", tapOn)
        StatusRow("Overlay permission", overlayOn)

        if (!tapOn) {
            Button(
                onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Enable tap service") }
            Text(
                "Sideloaded and greyed out? Open the app's info page, tap the ⋮ menu, then Allow restricted settings.",
                color = Color(0xFFCFCBFF),
                fontSize = 12.sp,
            )
        }
        if (!overlayOn) {
            Button(
                onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Allow overlay") }
        }
        if (tapOn && overlayOn) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { ctx.startForegroundService(Intent(ctx, OverlayService::class.java)) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Indigo),
                ) { Text("Launch bubble", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = { ctx.stopService(Intent(ctx, OverlayService::class.java)) },
                ) { Text("Stop bubble", color = Color.White) }
            }
        }

        OutlinedTextField(
            value = text,
            onValueChange = { text = it; msg = "" },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White),
            label = { Text("Profile (JSON)") },
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                msg = try {
                    ProfileStore.save(ctx, text)
                    "Saved"
                } catch (e: Exception) {
                    "Not saved: ${e.message?.take(120)}"
                }
            }) { Text("Save profile") }
            Spacer(Modifier.width(12.dp))
            Text(msg, color = Butter, fontSize = 13.sp)
        }
    }
}
