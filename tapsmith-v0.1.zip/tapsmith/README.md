# Tapsmith v0.1

A game-agnostic tap/swipe/loop engine with a floating bubble. Profiles are JSON.

## Profile steps
| type | fields |
|---|---|
| tap | x, y |
| swipe | x1, y1, x2, y2, ms |
| wait | ms, jitterMs |
| find | target, tapIt, timeoutMs, threshold, onFound[], onMissing[] (vision arrives in v0.2) |
| loop | times (0 = forever), maxMinutes (0 = no cap), steps[] |
| stop | (ends the run) |

## Using it
1. Push this repo; the Actions workflow builds the APK and posts it on the `tapsmith-latest` release.
2. Install, then: enable tap service, allow overlay, launch bubble.
3. Tap the bubble to run or stop. Drag to move. Long-press to close.

## Roadmap
- v0.2 screen capture + OpenCV matcher (`find` goes live), snip-to-save targets from the bubble
- v0.3 block editor UI (cards, drag to reorder, per-step test button)
- v0.4 confetti stats, profile list, import/export
