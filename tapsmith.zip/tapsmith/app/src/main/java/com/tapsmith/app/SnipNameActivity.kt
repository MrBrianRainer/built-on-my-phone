package com.tapsmith.app

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pops up over the game after a snip so you can name the image, then drops you back. */
class SnipNameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bmp = TargetStore.pendingBitmap(this)
        if (bmp == null) {
            finish()
            return
        }
        setContent {
            TapsmithTheme {
                NameDialog(
                    bmp,
                    onSave = { n ->
                        TargetStore.commitPending(this, n)
                        Toast.makeText(this, "Saved image [$n]", Toast.LENGTH_SHORT).show()
                        finish()
                    },
                    onCancel = {
                        TargetStore.discardPending(this)
                        finish()
                    },
                )
            }
        }
    }
}

@Composable
private fun NameDialog(bmp: Bitmap, onSave: (String) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(TargetStore.nextName(ctx)) }
    val exists = TargetStore.exists(ctx, cleanName(name))
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Panel,
        title = { Text("Name this image", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Snipped image",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp),
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name") },
                )
                if (exists) Text("That name exists. Saving replaces it.", color = Butter, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val c = cleanName(name)
                if (c.isNotEmpty()) onSave(c)
            }) { Text("Save image") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Color.White) } },
    )
}
