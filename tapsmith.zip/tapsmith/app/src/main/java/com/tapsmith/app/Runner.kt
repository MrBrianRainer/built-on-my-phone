package com.tapsmith.app

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.random.Random

private class StopSignal : RuntimeException()

/** Interprets a profile's steps. Knows nothing about any particular game. */
class Runner(
    private val svc: TapService,
    private val vision: Vision,
    private val screenW: Int,
    private val screenH: Int,
    private val onCount: (Int) -> Unit,
    private val onHit: (Hit) -> Unit,
) {
    private var count = 0

    suspend fun run(steps: List<Step>) {
        count = 0
        try {
            exec(steps)
        } catch (e: StopSignal) {
            RunLog.add("Stop step reached")
        }
    }

    private fun bump() { count++; onCount(count) }
    private fun jit(v: Int) = v + Random.nextInt(-4, 5)
    private fun now() = System.currentTimeMillis()

    private suspend fun exec(steps: List<Step>) {
        for (s in steps) {
            currentCoroutineContext().ensureActive()
            when (s) {
                is Tap -> {
                    RunLog.add("Tap (${s.x}, ${s.y})")
                    svc.tap(jit(s.x), jit(s.y), s.holdMs)
                    bump()
                }
                is Swipe -> {
                    RunLog.add("Swipe (${s.x1},${s.y1}) to (${s.x2},${s.y2})")
                    svc.swipe(jit(s.x1), jit(s.y1), jit(s.x2), jit(s.y2), s.ms)
                    bump()
                }
                is Wait -> {
                    val j = if (s.jitterMs > 0) Random.nextLong(-s.jitterMs, s.jitterMs + 1) else 0L
                    delay((s.ms + j).coerceAtLeast(0L))
                }
                is Press -> {
                    RunLog.add("Press ${s.button}")
                    svc.press(s.button)
                    bump()
                }
                is Find -> {
                    val r = look(listOf(s), s.timeoutMs, s.scroll)
                    if (r == null) {
                        val best = vision.bestSeen[s.target]
                        RunLog.add(
                            "Not found [${s.target}]" +
                                (if (best != null) " best ${"%.2f".format(best)} (needs ${"%.2f".format(s.threshold)})" else " (image missing?)")
                        )
                        exec(s.onMissing)
                    } else {
                        act(r.first, r.second)
                        exec(s.onFound)
                    }
                }
                is Priority -> {
                    val r = look(s.items, s.timeoutMs, s.scroll)
                    if (r == null) {
                        RunLog.add("None of ${s.items.size} priority images found")
                        exec(s.onNone)
                    } else {
                        act(r.first, r.second)
                        exec(r.first.onFound)
                    }
                }
                is Loop -> runLoop(s)
                is Stop -> throw StopSignal()
            }
        }
    }

    private suspend fun runLoop(s: Loop) {
        val end = if (s.maxMinutes > 0) now() + s.maxMinutes * 60_000L else Long.MAX_VALUE
        var i = 0
        while ((s.times == 0 || i < s.times) && now() < end) {
            currentCoroutineContext().ensureActive()
            if (s.untilFound.isNotEmpty() || s.untilGone.isNotEmpty()) {
                val f = vision.frame()
                if (f != null) {
                    var done = false
                    try {
                        if (s.untilFound.isNotEmpty() && vision.find(f, s.untilFound, 0.85, "all") != null) {
                            RunLog.add("Loop ends: [${s.untilFound}] appeared")
                            done = true
                        } else if (s.untilGone.isNotEmpty() && vision.find(f, s.untilGone, 0.85, "all") == null) {
                            RunLog.add("Loop ends: [${s.untilGone}] is gone")
                            done = true
                        }
                    } finally {
                        f.release()
                    }
                    if (done) return
                }
            }
            RunLog.add("Loop ${i + 1}")
            exec(s.steps)
            i++
            delay(50) // never spin the CPU on an empty loop
        }
    }

    /** Checks the screen for the items in priority order; scrolls or waits between attempts. */
    private suspend fun look(items: List<Find>, timeoutMs: Long, scroll: Scroll?): Pair<Find, Hit>? {
        val start = now()
        var tries = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val f = vision.frame()
            if (f != null) {
                try {
                    for (it in items) {
                        val h = vision.find(f, it.target, it.threshold, it.region)
                        if (h != null) return it to h
                    }
                } finally {
                    f.release()
                }
            }
            if (timeoutMs > 0 && now() - start >= timeoutMs) return null
            if (scroll != null) {
                if (tries >= scroll.maxTries) return null
                tries++
                RunLog.add("Scroll ${scroll.direction} $tries/${scroll.maxTries}")
                doScroll(scroll)
            } else if (timeoutMs <= 0) {
                return null
            } else {
                delay(300)
            }
        }
    }

    private suspend fun doScroll(sc: Scroll) {
        val cx = screenW / 2
        val cy = screenH / 2
        val dx = (screenW * sc.distance).toInt()
        val dy = (screenH * sc.distance).toInt()
        // "scroll down" reveals content below, so the finger swipes up
        val p = when (sc.direction) {
            "down" -> listOf(cx, cy + dy / 2, cx, cy - dy / 2)
            "up" -> listOf(cx, cy - dy / 2, cx, cy + dy / 2)
            "right" -> listOf(cx + dx / 2, cy, cx - dx / 2, cy)
            else -> listOf(cx - dx / 2, cy, cx + dx / 2, cy)
        }
        svc.swipe(p[0], p[1], p[2], p[3], 400)
        bump()
        delay(sc.settleMs)
    }

    private suspend fun act(f: Find, h: Hit) {
        onHit(h)
        RunLog.add("Found [${f.target}] ${"%.2f".format(h.score)} at (${h.x}, ${h.y})")
        when (f.action) {
            "tap" -> { svc.tap(jit(h.x + f.offsetX), jit(h.y + f.offsetY), 50L); bump() }
            "hold" -> { svc.tap(jit(h.x + f.offsetX), jit(h.y + f.offsetY), f.holdMs.coerceAtLeast(500L)); bump() }
            else -> {}
        }
    }
}
