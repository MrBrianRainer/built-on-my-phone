package com.tapsmith.app

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Everything a profile can do. Profiles are saved as JSON, but you edit them as cards. */
@Serializable
sealed interface Step

@Serializable @SerialName("tap")
data class Tap(val x: Int = 0, val y: Int = 0, val holdMs: Long = 50) : Step

@Serializable @SerialName("swipe")
data class Swipe(val x1: Int = 0, val y1: Int = 0, val x2: Int = 0, val y2: Int = 0, val ms: Long = 300) : Step

@Serializable @SerialName("wait")
data class Wait(val ms: Long = 1000, val jitterMs: Long = 0) : Step

/** button: back, home or recents */
@Serializable @SerialName("press")
data class Press(val button: String = "back") : Step

/**
 * Look for a saved image. action: tap, hold or none (none = just branch on found / not found).
 * region: all, top, bottom, left or right. timeoutMs 0 = look once (or until scroll tries run out).
 */
@Serializable @SerialName("find")
data class Find(
    val target: String = "",
    val action: String = "tap",
    val offsetX: Int = 0,
    val offsetY: Int = 0,
    val holdMs: Long = 50,
    val threshold: Double = 0.85,
    val region: String = "all",
    val timeoutMs: Long = 0,
    val scroll: Scroll? = null,
    val onFound: List<Step> = emptyList(),
    val onMissing: List<Step> = emptyList(),
) : Step

/** Ranked list: acts on the first image it sees, top of the list wins. */
@Serializable @SerialName("priority")
data class Priority(
    val items: List<Find> = emptyList(),
    val timeoutMs: Long = 0,
    val scroll: Scroll? = null,
    val onNone: List<Step> = emptyList(),
) : Step

/** times 0 = forever. maxMinutes 0 = no cap. untilFound / untilGone name an image that ends the loop. */
@Serializable @SerialName("loop")
data class Loop(
    val times: Int = 0,
    val maxMinutes: Int = 0,
    val untilFound: String = "",
    val untilGone: String = "",
    val steps: List<Step> = emptyList(),
) : Step

@Serializable @SerialName("stop")
data object Stop : Step

/** direction: down, up, left or right (which way the content scrolls). distance is a fraction of the screen. */
@Serializable
data class Scroll(
    val direction: String = "down",
    val maxTries: Int = 10,
    val distance: Double = 0.4,
    val settleMs: Long = 700,
)

@Serializable
data class Profile(val name: String, val steps: List<Step> = emptyList())

// ---------- helpers used by the UI ----------

fun List<Step>.countAll(): Int = sumOf { it.countSelf() }

private fun Step.countSelf(): Int = 1 + when (this) {
    is Loop -> steps.countAll()
    is Find -> onFound.countAll() + onMissing.countAll()
    is Priority -> items.sumOf { it.countSelf() } + onNone.countAll()
    else -> 0
}

fun List<Step>.targetsOf(): Set<String> = flatMap { it.targets() }.toSet()

fun Step.targets(): Set<String> = when (this) {
    is Find -> (if (target.isEmpty()) emptySet() else setOf(target)) + onFound.targetsOf() + onMissing.targetsOf()
    is Priority -> items.flatMap { it.targets() }.toSet() + onNone.targetsOf()
    is Loop -> setOfNotNull(untilFound.ifEmpty { null }, untilGone.ifEmpty { null }) + steps.targetsOf()
    else -> emptySet()
}

fun Step.renameTarget(old: String, new: String): Step = when (this) {
    is Find -> renameFind(old, new)
    is Priority -> copy(
        items = items.map { it.renameFind(old, new) },
        onNone = onNone.map { it.renameTarget(old, new) },
    )
    is Loop -> copy(
        untilFound = if (untilFound == old) new else untilFound,
        untilGone = if (untilGone == old) new else untilGone,
        steps = steps.map { it.renameTarget(old, new) },
    )
    else -> this
}

private fun Find.renameFind(old: String, new: String): Find = copy(
    target = if (target == old) new else target,
    onFound = onFound.map { it.renameTarget(old, new) },
    onMissing = onMissing.map { it.renameTarget(old, new) },
)

fun Step.emoji(): String = when (this) {
    is Tap -> "👆"
    is Swipe -> "👉"
    is Wait -> "⏱"
    is Press -> "⏎"
    is Find -> if (action == "none") "❓" else "🔍"
    is Priority -> "🥇"
    is Loop -> "🔁"
    is Stop -> "⛔"
}

fun Step.title(): String = when (this) {
    is Tap -> if (holdMs > 300) "Hold ($x, $y) for ${holdMs}ms" else "Tap ($x, $y)"
    is Swipe -> "Swipe ($x1, $y1) → ($x2, $y2)"
    is Wait -> "Wait ${ms}ms" + (if (jitterMs > 0) " ±$jitterMs" else "")
    is Press -> "Press $button"
    is Find -> findTitle()
    is Priority -> "Look for the first of ${items.size} image" + (if (items.size == 1) "" else "s") +
        (if (scroll != null) ", scrolling ${scroll.direction}" else "")
    is Loop -> loopTitle()
    is Stop -> "Stop the run"
}

private fun Find.findTitle(): String {
    val name = if (target.isEmpty()) "(pick an image)" else "[$target]"
    val wait = if (timeoutMs > 0) " (waits up to ${timeoutMs / 1000.0}s)" else ""
    if (action == "none") {
        return if (scroll != null) "Scroll ${scroll.direction} until $name is seen" else "If $name is on screen$wait"
    }
    val verb = if (action == "hold") "hold" else "tap"
    return if (scroll != null) "Scroll ${scroll.direction} until $name, then $verb it"
    else "Look for $name, then $verb it$wait"
}

private fun Loop.loopTitle(): String {
    var s = if (times == 0) "Repeat forever" else "Repeat $times times"
    if (maxMinutes > 0) s += ", max $maxMinutes min"
    if (untilFound.isNotEmpty()) s += ", until [$untilFound] appears"
    if (untilGone.isNotEmpty()) s += ", until [$untilGone] disappears"
    return s
}

fun Step.detail(): String? = when (this) {
    is Find -> {
        val parts = mutableListOf("match ≥ ${(threshold * 100).toInt()}%")
        if (region != "all") parts.add("region: $region")
        if (action != "none" && (offsetX != 0 || offsetY != 0)) parts.add("offset $offsetX,$offsetY")
        if (scroll != null) parts.add("up to ${scroll.maxTries} scrolls")
        parts.joinToString(" · ")
    }
    is Priority -> if (timeoutMs > 0) "waits up to ${timeoutMs / 1000.0}s" else null
    else -> null
}

enum class Kind(val emoji: String, val label: String, val hint: String) {
    FIND("🔍", "Look for an image", "Find a saved image, optionally scrolling, then tap it"),
    PRIORITY("🥇", "Look for first of several", "Ranked images: acts on the first one it sees"),
    IF_FOUND("❓", "If an image is found", "Run steps only when an image is on screen"),
    LOOP("🔁", "Repeat", "Loop steps N times, forever, or until an image shows or vanishes"),
    TAP("👆", "Tap a spot", "Tap or hold fixed screen coordinates"),
    SWIPE("👉", "Swipe", "Swipe between two spots"),
    WAIT("⏱", "Wait", "Pause, with optional random jitter"),
    PRESS("⏎", "Press back / home", "System buttons"),
    STOP("⛔", "Stop the run", "Ends the whole run here"),
}

fun newStep(kind: Kind, screenW: Int, screenH: Int): Step = when (kind) {
    Kind.FIND -> Find()
    Kind.PRIORITY -> Priority()
    Kind.IF_FOUND -> Find(action = "none")
    Kind.LOOP -> Loop()
    Kind.TAP -> Tap(screenW / 2, screenH / 2)
    Kind.SWIPE -> Swipe(screenW / 2, screenH * 3 / 4, screenW / 2, screenH / 4, 400)
    Kind.WAIT -> Wait(1000, 0)
    Kind.PRESS -> Press("back")
    Kind.STOP -> Stop
}
