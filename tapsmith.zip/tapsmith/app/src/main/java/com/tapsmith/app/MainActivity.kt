package com.tapsmith.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var refresh by mutableIntStateOf(0)

    private val capLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java)
                    .putExtra("code", res.resultCode)
                    .putExtra("data", data)
            )
            Toast.makeText(this, "Bubble launched. Open your game.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Screen capture wasn't allowed", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TapsmithTheme {
                App(refresh, onLaunch = { launchBubble() }, onStopBubble = { stopBubble() })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++ // re-check permissions when coming back from Settings
    }

    private fun launchBubble() {
        if (Bridge.service != null) {
            Toast.makeText(this, "Bubble is already running. Active profile updated.", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this) || TapService.instance == null) {
            Toast.makeText(this, "Finish setup first (Setup tab)", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        capLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun stopBubble() {
        stopService(Intent(this, OverlayService::class.java))
    }
}

@Composable
fun App(refresh: Int, onLaunch: () -> Unit, onStopBubble: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<String?>(null) }
    val ready = refresh >= 0 && TapService.instance != null && Settings.canDrawOverlays(ctx)

    Scaffold(
        containerColor = Indigo,
        bottomBar = {
            if (editing == null) {
                NavigationBar(containerColor = Panel) {
                    listOf("📋" to "Profiles", "🖼" to "Images", "📜" to "Log", "⚙" to "Setup")
                        .forEachIndexed { i, (e, l) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Text(e, fontSize = 20.sp) },
                                label = { Text(l, fontSize = 11.sp) },
                            )
                        }
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val e = editing
            if (e != null) {
                EditorScreen(e, onBack = { editing = null }, onUse = onLaunch)
            } else {
                when (tab) {
                    0 -> ProfilesScreen(refresh, ready, onEdit = { editing = it }, onLaunch = onLaunch)
                    1 -> TargetsScreen(refresh)
                    2 -> LogScreen()
                    else -> SetupScreen(refresh, onLaunch, onStopBubble)
                }
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, ready: Boolean, okText: String = "ready") {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(if (ready) Teal else Butter))
        Spacer(Modifier.width(10.dp))
        Text("$label: ${if (ready) okText else "needs setup"}", color = Color.White, fontSize = 15.sp)
    }
}

@Composable
fun SetupScreen(refresh: Int, onLaunch: () -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    val tapOn = refresh >= 0 && TapService.instance != null
    val overlayOn = refresh >= 0 && Settings.canDrawOverlays(ctx)
    val bubbleOn = refresh >= 0 && Bridge.service != null

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Title("Setup", "Do these once, then use the Profiles tab.")
        StatusRow("Tap service", tapOn)
        StatusRow("Overlay permission", overlayOn)
        StatusRow("Bubble", bubbleOn, okText = "running")

        if (!tapOn) {
            SmallBtn("1 · Enable tap service", {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, Modifier.fillMaxWidth(), filled = true)
            Lbl("Greyed out? Open this app's info page, tap the ⋮ menu, choose Allow restricted settings, then try again.")
        }
        if (!overlayOn) {
            SmallBtn("2 · Allow overlay", {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }, Modifier.fillMaxWidth(), filled = true)
        }
        if (tapOn && overlayOn) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallBtn("3 · Launch bubble", onLaunch, Modifier.weight(1f), filled = true)
                SmallBtn("Stop bubble", onStop)
            }
            Lbl("Android asks to share your screen each time. Choose Entire screen, then Start now.")
        }

        Text("How it works", color = Butter, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 12.dp))
        Text("1. Launch the bubble, then open your game.", color = Color.White, fontSize = 14.sp)
        Text("2. Tap the bubble for its menu: ▶ run the active profile, ✂ snip an image, 🔍 check that capture works, ✕ close.", color = Color.White, fontSize = 14.sp)
        Text("3. Back in the app, build a profile from cards in the Profiles tab. Use 🧪 on any step to test it on your game.", color = Color.White, fontSize = 14.sp)
        Text("4. While a run is going, tap the bubble to stop it. Long-press the bubble to close it.", color = Color.White, fontSize = 14.sp)
        Text("The Log tab shows every tap and every match score, so you can tune how strict an image match is.", color = Dim, fontSize = 13.sp)
    }
}
