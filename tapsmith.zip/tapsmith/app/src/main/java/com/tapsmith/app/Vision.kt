package com.tapsmith.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.delay
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/** A found image: center point, size and match score, all in full-resolution screen pixels. */
data class Hit(val x: Int, val y: Int, val w: Int, val h: Int, val score: Double)

class Frame(val gray: Mat) {
    fun release() = gray.release()
}

/** The "eyes": mirrors the screen into an ImageReader and hands out the latest frame. */
class Capture(
    private val ctx: Context,
    private val mp: MediaProjection,
    private val onStopped: () -> Unit,
) {
    private val handler = Handler(Looper.getMainLooper())
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var w = 0
    private var h = 0
    private var last: Bitmap? = null
    @Volatile private var released = false

    init {
        // Android 14+ requires a callback to be registered before creating the display
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                teardown()
                if (!released) onStopped()
            }
        }, handler)
        build()
    }

    @Suppress("DEPRECATION")
    fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    @Synchronized
    private fun build() {
        val (sw, sh) = screenSize()
        w = sw
        h = sh
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = mp.createVirtualDisplay(
            "tapsmith", w, h, ctx.resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null,
        )
        last = null
    }

    @Synchronized
    private fun teardown() {
        display?.release()
        display = null
        reader?.close()
        reader = null
    }

    fun release() {
        released = true
        teardown()
        runCatching { mp.stop() }
    }

    /** Latest screen frame. A static screen produces no new frames, so the last one is reused. */
    suspend fun latest(waitMs: Long): Bitmap? {
        var waited = 0L
        while (true) {
            val b = poll()
            if (b != null) return b
            if (released || waited >= waitMs) return null
            delay(50)
            waited += 50
        }
    }

    @Synchronized
    private fun poll(): Bitmap? {
        val r = reader ?: return null
        val (sw, sh) = screenSize()
        if (sw != w || sh != h) { // screen rotated: rebuild at the new size
            teardown()
            build()
            return null
        }
        val img = r.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val rowPad = p.rowStride - p.pixelStride * w
                val wide = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
                wide.copyPixelsFromBuffer(p.buffer)
                last = if (rowPad == 0) wide else Bitmap.createBitmap(wide, 0, 0, w, h)
            } finally {
                img.close()
            }
        }
        return last
    }
}

/** The "brain": OpenCV template matching against saved images. */
class Vision(private val ctx: Context, private val capture: Capture) {
    private val scale = 0.5 // match at half size: ~16x faster, plenty accurate for icons
    private val cache = HashMap<String, Pair<Long, Mat>>()
    val bestSeen = HashMap<String, Double>()

    suspend fun frame(): Frame? {
        val bmp = capture.latest(1500) ?: return null
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        val small = Mat()
        Imgproc.resize(gray, small, Size(gray.cols() * scale, gray.rows() * scale), 0.0, 0.0, Imgproc.INTER_AREA)
        gray.release()
        return Frame(small)
    }

    private fun template(name: String): Mat? {
        val f = TargetStore.file(ctx, name)
        if (!f.exists()) return null
        val stamp = f.lastModified()
        val cached = cache[name]
        if (cached != null && cached.first == stamp) return cached.second
        cached?.second?.release()
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        val small = Mat()
        Imgproc.resize(gray, small, Size(gray.cols() * scale, gray.rows() * scale), 0.0, 0.0, Imgproc.INTER_AREA)
        gray.release()
        cache[name] = stamp to small
        return small
    }

    private fun regionRect(cols: Int, rows: Int, region: String): Rect = when (region) {
        "top" -> Rect(0, 0, cols, rows / 2)
        "bottom" -> Rect(0, rows / 2, cols, rows - rows / 2)
        "left" -> Rect(0, 0, cols / 2, rows)
        "right" -> Rect(cols / 2, 0, cols - cols / 2, rows)
        else -> Rect(0, 0, cols, rows)
    }

    fun find(f: Frame, name: String, threshold: Double, region: String): Hit? {
        if (name.isEmpty()) return null
        val t = template(name) ?: return null
        val r = regionRect(f.gray.cols(), f.gray.rows(), region)
        if (t.cols() > r.width || t.rows() > r.height) return null
        val sub = Mat(f.gray, r)
        val res = Mat()
        Imgproc.matchTemplate(sub, t, res, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(res)
        res.release()
        sub.release()
        val score = mm.maxVal
        bestSeen[name] = if (score.isNaN()) 0.0 else score
        if (!(score >= threshold)) return null
        val cx = (r.x + mm.maxLoc.x + t.cols() / 2.0) / scale
        val cy = (r.y + mm.maxLoc.y + t.rows() / 2.0) / scale
        return Hit(cx.toInt(), cy.toInt(), (t.cols() / scale).toInt(), (t.rows() / scale).toInt(), score)
    }
}
