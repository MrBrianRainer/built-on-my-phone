package com.tapsmith.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Full-screen frozen frame. Drag a box around the thing you want the app to find. */
class SnipLayer(
    ctx: Context,
    private val bmp: Bitmap,
    onCancel: () -> Unit,
    onUse: (Rect) -> Unit,
) : FrameLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val useBtn = Button(ctx)
    private val canvasView = SnipCanvas(ctx, bmp) { has ->
        useBtn.isEnabled = has
        useBtn.alpha = if (has) 1f else 0.4f
    }

    init {
        addView(canvasView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val hint = TextView(ctx).apply {
            text = "Drag a box around what the app should find"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 24 * d; setColor(0xCC1B1464.toInt()) }
        }
        addView(hint, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = (64 * d).toInt()
        })

        useBtn.text = "Use this"
        useBtn.isEnabled = false
        useBtn.alpha = 0.4f
        useBtn.setOnClickListener { canvasView.selection()?.let(onUse) }
        val cancel = Button(ctx).apply {
            text = "Cancel"
            setOnClickListener { onCancel() }
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(cancel, LinearLayout.LayoutParams(0, FrameLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = (8 * d).toInt() })
            addView(useBtn, LinearLayout.LayoutParams(0, FrameLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        addView(row, FrameLayout.LayoutParams((300 * d).toInt(), FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = (90 * d).toInt()
        })
    }
}

private class SnipCanvas(
    ctx: Context,
    private val bmp: Bitmap,
    private val onSelect: (Boolean) -> Unit,
) : View(ctx) {

    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint().apply {
        color = 0xFFFFD23F.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val loc = IntArray(2)
    private var sel: Rect? = null
    private var x0 = 0
    private var y0 = 0

    fun selection(): Rect? = sel

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        // draw in screen coordinates so the frame lines up exactly with what was captured
        val ox = -loc[0].toFloat()
        val oy = -loc[1].toFloat()
        c.drawBitmap(bmp, ox, oy, null)
        c.drawRect(ox, oy, ox + bmp.width, oy + bmp.height, dim)
        val s = sel ?: return
        c.save()
        c.clipRect(s.left + ox, s.top + oy, s.right + ox, s.bottom + oy)
        c.drawBitmap(bmp, ox, oy, null)
        c.restore()
        c.drawRect(s.left + ox, s.top + oy, s.right + ox, s.bottom + oy, border)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.rawX.toInt().coerceIn(0, bmp.width)
        val y = e.rawY.toInt().coerceIn(0, bmp.height)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { x0 = x; y0 = y; sel = null; onSelect(false) }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                val r = Rect(min(x0, x), min(y0, y), max(x0, x), max(y0, y))
                sel = r
                if (e.action == MotionEvent.ACTION_UP) onSelect(r.width() >= 24 && r.height() >= 24)
                invalidate()
            }
        }
        return true
    }
}
