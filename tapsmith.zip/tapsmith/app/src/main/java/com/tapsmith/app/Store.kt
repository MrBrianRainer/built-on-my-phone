package com.tapsmith.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Letters, digits, space, dash, underscore, dot. Used for profile and image names. */
fun cleanName(s: String): String = s.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim()

object RunLog {
    val lines = MutableStateFlow<List<String>>(emptyList())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun add(s: String) {
        val t = synchronized(fmt) { fmt.format(Date()) }
        lines.update { (it + "$t  $s").takeLast(300) }
    }

    fun clear() { lines.value = emptyList() }
}

/** Lets the app talk to the running bubble service. */
object Bridge {
    @Volatile var service: OverlayService? = null
}

object ProfileStore {
    private val json = Json {
        classDiscriminator = "type"
        prettyPrint = true
        encodeDefaults = true
        ignoreUnknownKeys = true
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "profiles").apply { mkdirs() }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tapsmith", Context.MODE_PRIVATE)

    fun list(ctx: Context): List<String> {
        seedIfNeeded(ctx)
        return dir(ctx).listFiles(FileFilter { it.extension == "json" })
            ?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()
    }

    fun load(ctx: Context, name: String): Profile? {
        if (name.isEmpty()) return null
        return runCatching {
            json.decodeFromString<Profile>(File(dir(ctx), "$name.json").readText())
        }.getOrNull()
    }

    /** Same name overwrites the existing profile. */
    fun save(ctx: Context, p: Profile) {
        val n = cleanName(p.name)
        if (n.isEmpty()) return
        File(dir(ctx), "$n.json").writeText(json.encodeToString(p.copy(name = n)))
    }

    fun delete(ctx: Context, name: String) {
        File(dir(ctx), "$name.json").delete()
        if (active(ctx) == name) setActive(ctx, "")
    }

    fun duplicate(ctx: Context, name: String) {
        val p = load(ctx, name) ?: return
        var n = "$name copy"
        var i = 2
        while (File(dir(ctx), "$n.json").exists()) { n = "$name copy $i"; i++ }
        save(ctx, p.copy(name = n))
    }

    fun rename(ctx: Context, old: String, new: String): String {
        val n = cleanName(new)
        if (n.isEmpty() || n == old) return old
        val p = load(ctx, old) ?: return old
        save(ctx, p.copy(name = n))
        File(dir(ctx), "$old.json").delete()
        if (active(ctx) == old) setActive(ctx, n)
        return n
    }

    fun active(ctx: Context): String = prefs(ctx).getString("active", "") ?: ""
    fun setActive(ctx: Context, name: String) { prefs(ctx).edit().putString("active", name).apply() }

    /** Called when an image is renamed so profiles keep pointing at it. */
    fun renameTarget(ctx: Context, old: String, new: String) {
        for (n in list(ctx)) {
            val p = load(ctx, n) ?: continue
            if (old in p.steps.targetsOf()) {
                save(ctx, p.copy(steps = p.steps.map { it.renameTarget(old, new) }))
            }
        }
    }

    private fun seedIfNeeded(ctx: Context) {
        val pr = prefs(ctx)
        if (pr.getBoolean("seeded", false)) return
        pr.edit().putBoolean("seeded", true).apply()
        val m = ctx.resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        save(
            ctx,
            Profile(
                "Demo - swipe and tap",
                listOf(
                    Loop(
                        times = 5,
                        steps = listOf(
                            Swipe(w / 2, h * 3 / 4, w / 2, h / 4, 400),
                            Wait(800, 300),
                            Tap(w / 2, h / 2),
                            Wait(1000, 400),
                        ),
                    ),
                ),
            ),
        )
        save(
            ctx,
            Profile(
                "Example - scroll, find, collect",
                listOf(
                    Loop(
                        maxMinutes = 10,
                        steps = listOf(
                            Priority(
                                items = listOf(
                                    Find(target = "close popup"),
                                    Find(target = "claim button"),
                                ),
                                timeoutMs = 1500,
                            ),
                            Find(
                                target = "gold icon",
                                scroll = Scroll("down", 10, 0.4, 700),
                                onFound = listOf(
                                    Wait(1000, 300),
                                    Find(target = "collect button", timeoutMs = 3000),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        )
        if (active(ctx).isEmpty()) setActive(ctx, "Demo - swipe and tap")
    }
}

object TargetStore {
    private fun dir(ctx: Context) = File(ctx.filesDir, "targets").apply { mkdirs() }
    private fun pending(ctx: Context) = File(ctx.filesDir, "pending.png")

    fun file(ctx: Context, name: String) = File(dir(ctx), "$name.png")
    fun exists(ctx: Context, name: String) = file(ctx, name).exists()

    fun list(ctx: Context): List<String> =
        dir(ctx).listFiles(FileFilter { it.extension == "png" })
            ?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    fun size(ctx: Context, name: String): Pair<Int, Int>? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file(ctx, name).path, o)
        return if (o.outWidth > 0) o.outWidth to o.outHeight else null
    }

    fun thumb(ctx: Context, name: String, max: Int = 160): Bitmap? {
        val (w, h) = size(ctx, name) ?: return null
        var sample = 1
        while (w / (sample * 2) >= max || h / (sample * 2) >= max) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file(ctx, name).path, o)
    }

    fun delete(ctx: Context, name: String) { file(ctx, name).delete() }

    fun rename(ctx: Context, old: String, new: String): String {
        val n = cleanName(new)
        if (n.isEmpty() || n == old) return old
        val dest = file(ctx, n)
        if (dest.exists()) dest.delete()
        if (file(ctx, old).renameTo(dest)) ProfileStore.renameTarget(ctx, old, n)
        return n
    }

    fun nextName(ctx: Context): String {
        var i = 1
        while (exists(ctx, "image $i")) i++
        return "image $i"
    }

    fun savePending(ctx: Context, bmp: Bitmap) {
        pending(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun pendingBitmap(ctx: Context): Bitmap? =
        if (pending(ctx).exists()) BitmapFactory.decodeFile(pending(ctx).path) else null

    /** Same name replaces the existing image. */
    fun commitPending(ctx: Context, name: String) {
        val dest = file(ctx, name)
        if (dest.exists()) dest.delete()
        pending(ctx).copyTo(dest, overwrite = true)
        pending(ctx).delete()
    }

    fun discardPending(ctx: Context) { pending(ctx).delete() }
}
