package com.tapsmith.app

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- small shared pieces ----------

@Composable
fun Title(text: String, sub: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(text, fontSize = 30.sp, fontWeight = FontWeight.Black, color = Butter)
        if (sub != null) Text(sub, color = Dim, fontSize = 14.sp)
    }
}

@Composable
fun Lbl(text: String) {
    Text(text, color = Dim, fontSize = 12.sp)
}

@Composable
fun Banner(text: String) {
    Text(
        text,
        color = Indigo,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.fillMaxWidth().background(Butter, RoundedCornerShape(12.dp)).padding(12.dp),
    )
}

@Composable
fun SmallBtn(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    color: Color = Color.White,
    hPad: Dp = 12.dp,
    size: TextUnit = 14.sp,
) {
    val pad = PaddingValues(horizontal = hPad, vertical = 6.dp)
    if (filled) {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            contentPadding = pad,
            colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Indigo),
        ) { Text(text, fontWeight = FontWeight.Bold, fontSize = size, maxLines = 1) }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier, contentPadding = pad) {
            Text(text, color = if (enabled) color else color.copy(alpha = 0.35f), fontSize = size, maxLines = 1)
        }
    }
}

@Composable
fun NumField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { s -> onValue(s.filter { it.isDigit() || it == '.' || it == '-' }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { o ->
            SmallBtn(o, { onSelect(o) }, Modifier.weight(1f), filled = o == selected, hPad = 2.dp, size = 12.sp)
        }
    }
}

@Composable
fun FormDialog(title: String, onSave: () -> Unit, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title, color = Color.White) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content,
            )
        },
        confirmButton = { Button(onClick = onSave) { Text("Done") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) } },
    )
}

@Composable
fun TextPromptDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title, color = Color.White) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        },
        confirmButton = {
            Button(onClick = {
                val c = cleanName(text)
                if (c.isNotEmpty()) onConfirm(c)
            }) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) } },
    )
}

@Composable
fun TargetField(label: String, value: String, onValue: (String) -> Unit, allowClear: Boolean = false) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Lbl(label)
    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
        Text(if (value.isEmpty()) "Choose image…" else value, color = Color.White)
    }
    if (open) {
        val names = remember { TargetStore.list(ctx) }
        AlertDialog(
            onDismissRequest = { open = false },
            containerColor = Panel,
            title = { Text("Choose an image", color = Color.White) },
            text = {
                if (names.isEmpty()) {
                    Text("No images yet. Launch the bubble, open your game, tap the bubble, then tap ✂ to snip one.", color = Dim)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 360.dp)) {
                        items(names) { n ->
                            val bmp = remember(n) { TargetStore.thumb(ctx, n, 96) }
                            Row(
                                Modifier.fillMaxWidth().clickable { onValue(n); open = false }.padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = n, modifier = Modifier.size(44.dp))
                                Text(n, color = Color.White)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                Row {
                    if (allowClear && value.isNotEmpty()) {
                        TextButton(onClick = { onValue(""); open = false }) { Text("Clear", color = Coral) }
                    }
                    TextButton(onClick = { open = false }) { Text("Close", color = Color.White) }
                }
            },
        )
    }
}

class ScrollDraft(s: Scroll?) {
    var on by mutableStateOf(s != null)
    var dir by mutableStateOf(s?.direction ?: "down")
    var tries by mutableStateOf((s?.maxTries ?: 10).toString())
    var dist by mutableStateOf(((s?.distance ?: 0.4) * 100).toInt().toString())
    var settle by mutableStateOf((s?.settleMs ?: 700L).toString())

    fun build(): Scroll? =
        if (!on) null
        else Scroll(
            dir,
            tries.toIntOrNull() ?: 10,
            ((dist.toIntOrNull() ?: 40) / 100.0).coerceIn(0.1, 0.9),
            settle.toLongOrNull() ?: 700L,
        )
}

@Composable
fun ScrollEditor(d: ScrollDraft) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Scroll to search", color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = d.on, onCheckedChange = { d.on = it })
    }
    if (d.on) {
        Lbl("Which way the content moves")
        ChoiceRow(listOf("down", "up", "left", "right"), d.dir) { d.dir = it }
        NumField("Max scrolls before giving up", d.tries) { d.tries = it }
        NumField("Swipe distance (% of screen)", d.dist) { d.dist = it }
        NumField("Pause after each scroll (ms)", d.settle) { d.settle = it }
    }
}

private fun secs(ms: Long): String = if (ms % 1000L == 0L) (ms / 1000L).toString() else (ms / 1000.0).toString()

// ---------- step edit dialogs ----------

@Composable
fun EditStepDialog(step: Step, inPriority: Boolean, onSave: (Step) -> Unit, onDismiss: () -> Unit) {
    when (step) {
        is Tap -> {
            var x by remember { mutableStateOf(step.x.toString()) }
            var y by remember { mutableStateOf(step.y.toString()) }
            var hold by remember { mutableStateOf(step.holdMs.toString()) }
            FormDialog("Tap a spot", { onSave(Tap(x.toIntOrNull() ?: 0, y.toIntOrNull() ?: 0, hold.toLongOrNull() ?: 50L)) }, onDismiss) {
                NumField("X (pixels from left)", x) { x = it }
                NumField("Y (pixels from top)", y) { y = it }
                NumField("Hold time (ms). 50 is a quick tap", hold) { hold = it }
            }
        }
        is Swipe -> {
            var x1 by remember { mutableStateOf(step.x1.toString()) }
            var y1 by remember { mutableStateOf(step.y1.toString()) }
            var x2 by remember { mutableStateOf(step.x2.toString()) }
            var y2 by remember { mutableStateOf(step.y2.toString()) }
            var ms by remember { mutableStateOf(step.ms.toString()) }
            FormDialog("Swipe", {
                onSave(Swipe(x1.toIntOrNull() ?: 0, y1.toIntOrNull() ?: 0, x2.toIntOrNull() ?: 0, y2.toIntOrNull() ?: 0, ms.toLongOrNull() ?: 300L))
            }, onDismiss) {
                NumField("Start X", x1) { x1 = it }
                NumField("Start Y", y1) { y1 = it }
                NumField("End X", x2) { x2 = it }
                NumField("End Y", y2) { y2 = it }
                NumField("Duration (ms)", ms) { ms = it }
            }
        }
        is Wait -> {
            var ms by remember { mutableStateOf(step.ms.toString()) }
            var j by remember { mutableStateOf(step.jitterMs.toString()) }
            FormDialog("Wait", { onSave(Wait(ms.toLongOrNull() ?: 1000L, j.toLongOrNull() ?: 0L)) }, onDismiss) {
                NumField("Wait (ms)", ms) { ms = it }
                NumField("Random extra or less (± ms)", j) { j = it }
            }
        }
        is Press -> {
            var b by remember { mutableStateOf(step.button) }
            FormDialog("Press a system button", { onSave(Press(b)) }, onDismiss) {
                ChoiceRow(listOf("back", "home", "recents"), b) { b = it }
            }
        }
        is Find -> {
            var target by remember { mutableStateOf(step.target) }
            var action by remember { mutableStateOf(step.action) }
            var ox by remember { mutableStateOf(step.offsetX.toString()) }
            var oy by remember { mutableStateOf(step.offsetY.toString()) }
            var hold by remember { mutableStateOf(step.holdMs.toString()) }
            var thr by remember { mutableStateOf((step.threshold * 100).toInt().toString()) }
            var region by remember { mutableStateOf(step.region) }
            var timeout by remember { mutableStateOf(secs(step.timeoutMs)) }
            val sc = remember { ScrollDraft(step.scroll) }
            FormDialog(if (step.action == "none") "If an image is found" else "Look for an image", {
                onSave(
                    step.copy(
                        target = target,
                        action = action,
                        offsetX = ox.toIntOrNull() ?: 0,
                        offsetY = oy.toIntOrNull() ?: 0,
                        holdMs = hold.toLongOrNull() ?: 50L,
                        threshold = ((thr.toIntOrNull() ?: 85) / 100.0).coerceIn(0.3, 0.99),
                        region = region,
                        timeoutMs = if (inPriority) step.timeoutMs else ((timeout.toDoubleOrNull() ?: 0.0) * 1000).toLong(),
                        scroll = if (inPriority) null else sc.build(),
                    )
                )
            }, onDismiss) {
                TargetField("Image to look for", target, { target = it })
                Lbl("When found")
                ChoiceRow(listOf("tap", "hold", "none"), action) { a ->
                    action = a
                    if (a == "hold" && (hold.toLongOrNull() ?: 0L) < 500L) hold = "1000"
                }
                if (action != "none") {
                    NumField("Offset X from the image center (px)", ox) { ox = it }
                    NumField("Offset Y from the image center (px)", oy) { oy = it }
                }
                if (action == "hold") NumField("Hold time (ms)", hold) { hold = it }
                Lbl("Search area")
                ChoiceRow(listOf("all", "top", "bottom", "left", "right"), region) { region = it }
                NumField("Match strictness (%). Lower finds more, higher is pickier", thr) { thr = it }
                if (!inPriority) {
                    NumField("Wait up to (seconds). 0 = look once", timeout) { timeout = it }
                    ScrollEditor(sc)
                }
            }
        }
        is Priority -> {
            var timeout by remember { mutableStateOf(secs(step.timeoutMs)) }
            val sc = remember { ScrollDraft(step.scroll) }
            FormDialog("Look for the first of several", {
                onSave(step.copy(timeoutMs = ((timeout.toDoubleOrNull() ?: 0.0) * 1000).toLong(), scroll = sc.build()))
            }, onDismiss) {
                Lbl("Add the images inside the card. The top one wins when several are on screen.")
                NumField("Wait up to (seconds). 0 = look once", timeout) { timeout = it }
                ScrollEditor(sc)
            }
        }
        is Loop -> {
            var times by remember { mutableStateOf(step.times.toString()) }
            var mins by remember { mutableStateOf(step.maxMinutes.toString()) }
            var uf by remember { mutableStateOf(step.untilFound) }
            var ug by remember { mutableStateOf(step.untilGone) }
            FormDialog("Repeat", {
                onSave(step.copy(times = times.toIntOrNull() ?: 0, maxMinutes = mins.toIntOrNull() ?: 0, untilFound = uf, untilGone = ug))
            }, onDismiss) {
                NumField("Times to repeat. 0 = forever", times) { times = it }
                NumField("Stop after (minutes). 0 = no limit", mins) { mins = it }
                TargetField("Stop when this image appears", uf, { uf = it }, allowClear = true)
                TargetField("Stop when this image disappears", ug, { ug = it }, allowClear = true)
            }
        }
        is Stop -> {}
    }
}

@Composable
private fun AddDialog(allowed: List<Kind>, onPick: (Kind) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Add a step", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                allowed.forEach { k ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(k) }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(k.emoji, fontSize = 24.sp)
                        Column {
                            Text(k.label, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(k.hint, color = Dim, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Color.White) } },
    )
}

// ---------- the card list ----------

@Composable
fun StepList(
    steps: List<Step>,
    onChange: (List<Step>) -> Unit,
    allowed: List<Kind> = Kind.values().toList(),
    inPriority: Boolean = false,
    depth: Int = 0,
) {
    val ctx = LocalContext.current
    var adding by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(start = if (depth > 0) 12.dp else 0.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        steps.forEachIndexed { i, s ->
            StepCard(
                step = s,
                index = i,
                count = steps.size,
                inPriority = inPriority,
                depth = depth,
                onReplace = { n -> onChange(steps.toMutableList().also { it[i] = n }) },
                onMove = { dir ->
                    val j = i + dir
                    if (j in steps.indices) {
                        onChange(steps.toMutableList().also { l -> val t = l[i]; l[i] = l[j]; l[j] = t })
                    }
                },
                onDelete = { onChange(steps.toMutableList().also { it.removeAt(i) }) },
            )
        }
        SmallBtn("＋ Add step", { adding = true }, Modifier.fillMaxWidth())
    }
    if (adding) {
        AddDialog(
            allowed,
            onPick = { k ->
                val m = ctx.resources.displayMetrics
                onChange(steps + newStep(k, m.widthPixels, m.heightPixels))
                adding = false
            },
            onDismiss = { adding = false },
        )
    }
}

@Composable
private fun StepCard(
    step: Step,
    index: Int,
    count: Int,
    inPriority: Boolean,
    depth: Int,
    onReplace: (Step) -> Unit,
    onMove: (Int) -> Unit,
    onDelete: () -> Unit,
) {
    val ctx = LocalContext.current
    var edit by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(step.emoji(), fontSize = 20.sp)
                Column(Modifier.weight(1f)) {
                    Text(step.title(), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    val dtl = step.detail()
                    if (dtl != null) Text(dtl, color = Dim, fontSize = 12.sp)
                    if (step is Find && step.target.isNotEmpty() && !TargetStore.exists(ctx, step.target)) {
                        Text("⚠ No saved image named [${step.target}]", color = Butter, fontSize = 12.sp)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                SmallBtn("⬆", { onMove(-1) }, enabled = index > 0, hPad = 10.dp)
                SmallBtn("⬇", { onMove(1) }, enabled = index < count - 1, hPad = 10.dp)
                if (step !is Stop) SmallBtn("Edit", { edit = true }, hPad = 10.dp)
                SmallBtn("🧪", {
                    val svc = Bridge.service
                    if (svc == null) {
                        Toast.makeText(ctx, "Launch the bubble first (Setup tab)", Toast.LENGTH_LONG).show()
                    } else {
                        svc.testStep(step)
                    }
                }, hPad = 10.dp)
                SmallBtn("🗑", onDelete, color = Coral, hPad = 10.dp)
            }
            when (step) {
                is Loop -> StepList(step.steps, { onReplace(step.copy(steps = it)) }, depth = depth + 1)
                is Find -> {
                    Lbl(if (step.action == "none") "Then:" else "After it's found:")
                    StepList(step.onFound, { onReplace(step.copy(onFound = it)) }, depth = depth + 1)
                    Lbl("If it's not found:")
                    StepList(step.onMissing, { onReplace(step.copy(onMissing = it)) }, depth = depth + 1)
                }
                is Priority -> {
                    Lbl("Images, top = highest priority:")
                    StepList(
                        step.items,
                        { n -> onReplace(step.copy(items = n.filterIsInstance<Find>())) },
                        allowed = listOf(Kind.FIND),
                        inPriority = true,
                        depth = depth + 1,
                    )
                    Lbl("If none are found:")
                    StepList(step.onNone, { onReplace(step.copy(onNone = it)) }, depth = depth + 1)
                }
                else -> {}
            }
        }
    }
    if (edit) {
        EditStepDialog(step, inPriority, onSave = { onReplace(it); edit = false }, onDismiss = { edit = false })
    }
}

// ---------- screens ----------

@Composable
fun ProfilesScreen(refresh: Int, ready: Boolean, onEdit: (String) -> Unit, onLaunch: () -> Unit) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val names = remember(version, refresh) { ProfileStore.list(ctx) }
    var active by remember(version, refresh) { mutableStateOf(ProfileStore.active(ctx)) }
    val have = remember(version, refresh) { TargetStore.list(ctx).toSet() }
    var newOpen by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Title("Profiles", "A profile is a recipe of steps. Tap Use, open your game, then run it from the bubble.") }
        if (!ready) item { Banner("Finish setup first: open the Setup tab.") }
        item { SmallBtn("＋ New profile", { newOpen = true }, Modifier.fillMaxWidth(), filled = true) }
        items(names) { name ->
            val p = remember(name, version) { ProfileStore.load(ctx, name) }
            val steps = p?.steps ?: emptyList()
            val missing = steps.targetsOf() - have
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (name == active) Pill("active")
                    }
                    Text("${steps.countAll()} steps", color = Dim, fontSize = 13.sp)
                    if (missing.isNotEmpty()) {
                        Text("⚠ Missing images: ${missing.joinToString()}", color = Butter, fontSize = 12.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("▶ Use", {
                            ProfileStore.setActive(ctx, name)
                            active = name
                            onLaunch()
                        }, filled = true, hPad = 10.dp)
                        SmallBtn("Edit", { onEdit(name) }, hPad = 10.dp)
                        SmallBtn("Copy", { ProfileStore.duplicate(ctx, name); version++ }, hPad = 10.dp)
                        SmallBtn("Delete", { deleting = name }, color = Coral, hPad = 10.dp)
                    }
                }
            }
        }
    }

    if (newOpen) {
        TextPromptDialog("New profile", "", "Create", onConfirm = { n ->
            newOpen = false
            if (n in names) {
                Toast.makeText(ctx, "That name exists, opening it", Toast.LENGTH_SHORT).show()
            } else {
                ProfileStore.save(ctx, Profile(n, emptyList()))
                version++
            }
            onEdit(n)
        }, onDismiss = { newOpen = false })
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = Panel,
            title = { Text("Delete \"$d\"?", color = Color.White) },
            text = { Text("This can't be undone.", color = Dim) },
            confirmButton = {
                Button(onClick = { ProfileStore.delete(ctx, d); deleting = null; version++ }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel", color = Color.White) } },
        )
    }
}

@Composable
fun EditorScreen(name: String, onBack: () -> Unit, onUse: () -> Unit) {
    val ctx = LocalContext.current
    var current by remember { mutableStateOf(name) }
    var steps by remember { mutableStateOf(ProfileStore.load(ctx, name)?.steps ?: emptyList()) }
    var renaming by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallBtn("◀ Back", onBack)
            Spacer(Modifier.weight(1f))
            Pill("Saved ✓")
        }
        Spacer(Modifier.height(8.dp))
        Text(current, fontSize = 24.sp, fontWeight = FontWeight.Black, color = Butter)
        Text("${steps.countAll()} steps. Every change saves instantly.", color = Dim, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallBtn("Rename", { renaming = true })
            SmallBtn("▶ Use this profile", {
                ProfileStore.setActive(ctx, current)
                onUse()
            }, filled = true)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 10.dp)) {
            StepList(steps, { n ->
                steps = n
                ProfileStore.save(ctx, Profile(current, n))
            })
            Spacer(Modifier.height(24.dp))
        }
    }
    if (renaming) {
        TextPromptDialog("Rename profile", current, "Rename", onConfirm = { n ->
            current = ProfileStore.rename(ctx, current, n)
            renaming = false
        }, onDismiss = { renaming = false })
    }
}

@Composable
fun TargetsScreen(refresh: Int) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val names = remember(version, refresh) { TargetStore.list(ctx) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Title("Images", "Things the app can look for. Snip them from the bubble while your game is open.") }
        if (names.isEmpty()) {
            item {
                Banner("No images yet. Launch the bubble, open your game, tap the bubble, then tap ✂ and drag a box around an icon.")
            }
        }
        items(names) { n ->
            val bmp = remember(n, version) { TargetStore.thumb(ctx, n) }
            val dims = remember(n, version) { TargetStore.size(ctx, n) }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = n, modifier = Modifier.size(64.dp))
                    Column(Modifier.weight(1f)) {
                        Text(n, color = Color.White, fontWeight = FontWeight.Bold)
                        if (dims != null) Text("${dims.first}×${dims.second} px", color = Dim, fontSize = 12.sp)
                    }
                    SmallBtn("Rename", { renaming = n }, hPad = 8.dp, size = 12.sp)
                    SmallBtn("🗑", { deleting = n }, color = Coral, hPad = 8.dp)
                }
            }
        }
    }

    val r = renaming
    if (r != null) {
        TextPromptDialog("Rename image", r, "Rename", onConfirm = { n ->
            TargetStore.rename(ctx, r, n)
            renaming = null
            version++
        }, onDismiss = { renaming = null })
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = Panel,
            title = { Text("Delete image \"$d\"?", color = Color.White) },
            text = { Text("Profiles that use it will show a warning until you pick another.", color = Dim) },
            confirmButton = {
                Button(onClick = { TargetStore.delete(ctx, d); deleting = null; version++ }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel", color = Color.White) } },
        )
    }
}

@Composable
fun LogScreen() {
    val lines by RunLog.lines.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        item { Title("Run log", "What the app saw and did. Newest first. Match scores here help you tune strictness.") }
        item { SmallBtn("Clear log", { RunLog.clear() }) }
        if (lines.isEmpty()) item { Text("Nothing yet.", color = Dim) }
        items(lines.reversed()) { l ->
            Text(l, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
    }
}
