package com.tapsmith.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.opencv.android.OpenCVLoader
import kotlin.math.abs

/**
 * The floating bubble. Tap it for the menu (run, snip, capture test, close).
 * While a run is going, tap it to stop. Drag to move. Long-press to close.
 */
class OverlayService : Service() {

    private enum class Mode(val color: Int, val label: String) {
        IDLE(0xFFFF5C8A.toInt(), "▶"),
        RUN(0xFF2EC4B6.toInt(), "0"),
        DONE(0xFF8E7DFF.toInt(), "✓"),
        ERROR(0xFFE63946.toInt(), "!"),
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var wm: WindowManager

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var menu: LinearLayout? = null
    private var menuShown = false
    private var snip: SnipLayer? = null

    private var capture: Capture? = null
    private var vision: Vision? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Bridge.service = this
        if (!OpenCVLoader.initLocal()) toast("OpenCV failed to load")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { readData(it) }
        if (data == null || code == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        setupProjection(code, data)
        if (bubble == null) addBubble()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    override fun onDestroy() {
        Bridge.service = null
        job?.cancel()
        scope.cancel()
        hideMenu()
        closeSnip()
        bubble?.let { runCatching { wm.removeView(it) } }
        capture?.release()
        super.onDestroy()
    }

    // ---------- setup ----------

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bubble", "Tapsmith bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "bubble")
            .setContentTitle("Tapsmith bubble is on")
            .setContentText("Long-press the bubble to close it")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupProjection(code: Int, data: Intent) {
        capture?.release()
        capture = null
        vision = null
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        val cap = Capture(this, mp) {
            job?.cancel()
            ui {
                paint(Mode.ERROR)
                toast("Screen capture stopped. Relaunch the bubble from the app.")
            }
        }
        capture = cap
        vision = Vision(this, cap)
    }

    // ---------- helpers ----------

    private fun ui(block: () -> Unit) { main.post { block() } }
    private fun toast(msg: String) = ui { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun fail(msg: String) {
        paint(Mode.ERROR)
        toast(msg)
        RunLog.add("✗ $msg")
    }

    private fun screenSize(): Pair<Int, Int> =
        capture?.screenSize() ?: (resources.displayMetrics.widthPixels to resources.displayMetrics.heightPixels)

    private fun paint(m: Mode, text: String = m.label) {
        val v = bubble ?: return
        v.text = text
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(m.color)
            setStroke((3 * resources.displayMetrics.density).toInt(), Color.WHITE)
        }
    }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    // ---------- bubble + menu ----------

    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (60 * d).toInt()
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        bubble = tv
        paint(Mode.IDLE)
        val lp = overlayParams(size, size, true).apply {
            x = (16 * d).toInt()
            y = (200 * d).toInt()
        }
        bubbleLp = lp
        tv.setOnTouchListener(DragListener(lp))
        wm.addView(tv, lp)
    }

    private fun buildMenu(): LinearLayout {
        val d = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (0 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 30 * d
                setColor(0xE62A2180.toInt())
            }
        }
        fun item(label: String, color: Int, onClick: () -> Unit) {
            val t = TextView(this).apply {
                text = label
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
                setOnClickListener { onClick() }
            }
            row.addView(t, LinearLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt()).apply {
                marginEnd = (6 * d).toInt()
            })
        }
        item("▶", 0xFF2EC4B6.toInt()) { startRun() }
        item("✂", 0xFFFF5C8A.toInt()) { startSnip() }
        item("🔍", 0xFF8E7DFF.toInt()) { captureTest() }
        item("✕", 0xFF555577.toInt()) { stopSelf() }
        return row
    }

    private fun showMenu() {
        val lp0 = bubbleLp ?: return
        val d = resources.displayMetrics.density
        val menuW = (212 * d).toInt()
        val menuH = (56 * d).toInt()
        val size = (60 * d).toInt()
        val gap = (8 * d).toInt()
        val (sw, _) = screenSize()
        val v = menu ?: buildMenu().also { menu = it }
        val lp = overlayParams(menuW, menuH, true).apply {
            x = if (lp0.x + size + gap + menuW <= sw) lp0.x + size + gap else lp0.x - menuW - gap
            y = lp0.y + (size - menuH) / 2
        }
        if (menuShown) hideMenu()
        wm.addView(v, lp)
        menuShown = true
    }

    private fun hideMenu() {
        if (!menuShown) return
        menu?.let { runCatching { wm.removeView(it) } }
        menuShown = false
    }

    private inner class DragListener(val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        if (!moved) hideMenu()
                        moved = true
                    }
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    when {
                        e.eventTime - e.downTime > 700 -> stopSelf()
                        job?.isActive == true -> stopRun()
                        menuShown -> hideMenu()
                        else -> showMenu()
                    }
                }
            }
            return true
        }
    }

    // ---------- running ----------

    private fun stopRun() {
        job?.cancel()
        paint(Mode.IDLE)
    }

    private fun startRun() {
        hideMenu()
        val svc = TapService.instance ?: return fail("Tap service is off. Turn it on in Accessibility settings.")
        val v = vision ?: return fail("Screen capture isn't running. Relaunch the bubble from the app.")
        val name = ProfileStore.active(this)
        val profile = ProfileStore.load(this, name) ?: return fail("No active profile. Open the app, Profiles, tap Use.")
        val (w, h) = screenSize()
        paint(Mode.RUN, "0")
        RunLog.add("▶ Run \"${profile.name}\"")
        job = scope.launch {
            try {
                Runner(svc, v, w, h, { n -> ui { paint(Mode.RUN, n.toString()) } }, { hit -> flash(hit) })
                    .run(profile.steps)
                RunLog.add("✓ Finished")
                ui { paint(Mode.DONE) }
            } catch (e: CancellationException) {
                RunLog.add("■ Stopped")
                throw e
            } catch (e: Exception) {
                RunLog.add("✗ ${e.message}")
                ui {
                    paint(Mode.ERROR)
                    toast(e.message ?: "Run failed")
                }
            }
        }
    }

    /** Called from the editor's Test button: runs one step after a short countdown. */
    fun testStep(step: Step) {
        if (job?.isActive == true) {
            toast("Stop the current run first")
            return
        }
        val svc = TapService.instance ?: return fail("Tap service is off.")
        val v = vision ?: return fail("Screen capture isn't running.")
        val (w, h) = screenSize()
        toast("Testing in 4 seconds. Switch to your game now.")
        RunLog.add("🧪 Test: ${step.title()}")
        job = scope.launch {
            try {
                delay(4000)
                Runner(svc, v, w, h, {}, { hit -> flash(hit) }).run(listOf(step))
                RunLog.add("🧪 Test finished")
                toast("Test finished. Details are in the Log tab.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                RunLog.add("✗ ${e.message}")
                toast(e.message ?: "Test failed")
            }
        }
    }

    /** Yellow box around whatever was just found. */
    private fun flash(h: Hit) = ui {
        val d = resources.displayMetrics.density
        val v = View(this)
        v.background = GradientDrawable().apply {
            cornerRadius = 8 * d
            setColor(0x33FFD23F)
            setStroke((3 * d).toInt(), 0xFFFFD23F.toInt())
        }
        val lp = overlayParams(h.w.coerceAtLeast(24), h.h.coerceAtLeast(24), false).apply {
            x = h.x - h.w / 2
            y = h.y - h.h / 2
        }
        runCatching { wm.addView(v, lp) }
        main.postDelayed({ runCatching { wm.removeView(v) } }, 700)
    }

    // ---------- capture test + snip ----------

    private fun isBlack(b: Bitmap): Boolean {
        var bright = 0
        for (i in 0 until 24) {
            for (j in 0 until 24) {
                val p = b.getPixel((b.width - 1) * i / 23, (b.height - 1) * j / 23)
                val luma = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                if (luma > 10) bright++
            }
        }
        return bright == 0
    }

    private fun captureTest() {
        hideMenu()
        val cap = capture ?: return fail("Screen capture isn't running.")
        scope.launch {
            val bmp = cap.latest(1500)
            ui {
                when {
                    bmp == null -> toast("No frame received from the screen")
                    isBlack(bmp) -> toast("Capture is black. This app blocks screen capture.")
                    else -> toast("Capture works: ${bmp.width}×${bmp.height}")
                }
            }
        }
    }

    private fun startSnip() {
        hideMenu()
        val cap = capture ?: return fail("Screen capture isn't running.")
        bubble?.visibility = View.INVISIBLE // keep the bubble out of the picture
        scope.launch {
            delay(350)
            val bmp = cap.latest(1500)
            ui {
                if (bmp == null) {
                    bubble?.visibility = View.VISIBLE
                    toast("Couldn't capture the screen")
                } else {
                    showSnip(bmp)
                }
            }
        }
    }

    private fun showSnip(bmp: Bitmap) {
        val layer = SnipLayer(this, bmp, onCancel = { closeSnip() }, onUse = { r -> finishSnip(bmp, r) })
        snip = layer
        val lp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true)
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(layer, lp)
    }

    private fun closeSnip() {
        snip?.let { runCatching { wm.removeView(it) } }
        snip = null
        bubble?.visibility = View.VISIBLE
    }

    private fun finishSnip(bmp: Bitmap, r: Rect) {
        val x = r.left.coerceIn(0, bmp.width - 1)
        val y = r.top.coerceIn(0, bmp.height - 1)
        val w = r.width().coerceAtMost(bmp.width - x).coerceAtLeast(1)
        val h = r.height().coerceAtMost(bmp.height - y).coerceAtLeast(1)
        TargetStore.savePending(this, Bitmap.createBitmap(bmp, x, y, w, h))
        closeSnip()
        startActivity(Intent(this, SnipNameActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
