package com.tapsmith.app

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Indigo = Color(0xFF1B1464)
val Panel = Color(0xFF2A2180)
val Coral = Color(0xFFFF5C8A)
val Teal = Color(0xFF2EC4B6)
val Butter = Color(0xFFFFD23F)
val Dim = Color(0xFFCFCBFF)

@Composable
fun TapsmithTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Coral,
            onPrimary = Color.White,
            secondary = Teal,
            background = Indigo,
            surface = Panel,
            secondaryContainer = Color(0xFF3B31A8),
            onSecondaryContainer = Color.White,
        ),
        content = content,
    )
}

@Composable
fun Pill(text: String, color: Color = Teal) {
    Text(
        text,
        color = Indigo,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(color, RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}
