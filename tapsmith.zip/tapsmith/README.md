# Tapsmith v0.2

Game-agnostic tap / swipe / find / loop engine with a floating bubble and a card-based profile editor.

## Tabs
- Profiles: recipes of steps. Use = make active and launch the bubble. Edit = card editor (auto-saves).
- Images: saved snips (thumbnails, rename, delete).
- Log: every tap and every match score.
- Setup: permissions, launch/stop bubble.

## Bubble
Tap = menu (run, snip, capture test, close). While running, tap = stop. Drag to move. Long-press = close.

## Steps
Look for image (optional scroll-search, region, strictness, offset, hold), Look for first of several (ranked),
If image is found, Repeat (N / forever / minutes / until image appears or vanishes), Tap, Swipe, Wait (jitter),
Press back/home/recents, Stop.

## Build
Upload as `tapsmith.zip` to the repo root; the workflow unzips it, builds, and posts app-debug.apk on the
`tapsmith-latest` release. The APK is signed with a fixed key (tapsmith/debug.keystore) so updates install over the old one.
